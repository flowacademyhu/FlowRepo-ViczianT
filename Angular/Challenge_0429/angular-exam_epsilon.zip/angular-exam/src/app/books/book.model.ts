export class Book {
    constructor(public title: string, public subTitle: string) {}
}
