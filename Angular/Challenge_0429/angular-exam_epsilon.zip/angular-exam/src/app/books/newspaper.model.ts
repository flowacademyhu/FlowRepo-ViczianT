export class Newspaper {
    constructor(public name: string) {}
}
