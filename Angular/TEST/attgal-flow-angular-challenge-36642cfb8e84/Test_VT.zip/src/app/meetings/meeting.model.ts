export class Meeting {
    constructor(public title: string, public time: string) {}
}
