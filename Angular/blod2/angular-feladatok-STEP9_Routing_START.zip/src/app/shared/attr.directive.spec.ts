import { AttrDirective } from './attr.directive';

describe('AttrDirective', () => {
  it('should create an instance', () => {
    const directive = new AttrDirective();
    expect(directive).toBeTruthy();
  });
});
