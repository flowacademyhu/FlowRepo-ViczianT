import { GoodAttrDirective } from './good-attr.directive';

describe('GoodAttrDirective', () => {
  it('should create an instance', () => {
    const directive = new GoodAttrDirective();
    expect(directive).toBeTruthy();
  });
});
